# pragma pylint: disable=missing-docstring, invalid-name, pointless-string-statement
# flake8: noqa: F401
# isort: skip_file
import numpy as np
import pandas as pd
from pandas import DataFrame
from freqtrade.strategy import (IStrategy, IntParameter, DecimalParameter,
                                CategoricalParameter, BooleanParameter)
import talib.abstract as ta


class ORBAlgoStrategy(IStrategy):
    """
    Opening Range Breakout (ORB) Algo | Flux Charts
    ------------------------------------------------
    Ամենօրյա 45 րոպեանոց ORB-ի breakout (EMA-ով), retest-ի և ադապտիվ կառավարմամբ։
    Default կարգավորումները համապատասխանում են screenshot-ի ORB Algo-ին։
    """

    INTERFACE_VERSION = 3
    can_short = True

    timeframe = '15m'               # 15m կամ ավելի ցածր (պահանջը՝ <=15)
    process_only_new_candles = False

    # --- Stop‑loss (custom exit-ով ենք SL-ը վարելու) ---
    stoploss = -0.99
    use_custom_stoploss = False

    # --- Trailing Stop (չի օգտագործվում) ---
    trailing_stop = False

    # --- Entry / Exit պարամետրեր ---
    minimal_roi = {}          # ROI-ն կառավարվում է TP/SL-ով
    exit_pricing = {
        "price_side": "same",
        "use_order_book": False,
    }
    entry_pricing = {
        "price_side": "same",
        "use_order_book": False,
    }

    # ============================
    #   Օպտիմիզացվող պարամետրեր
    # ============================
    orb_minutes = IntParameter(15, 60, default=60, space="buy")           # ORB տևողություն (րոպե)
    sensitivity = CategoricalParameter(["High", "Medium", "Low", "Lowest"], default="Medium", space="buy")
    breakout_condition = CategoricalParameter(["Close", "EMA"], default="EMA", space="buy")
    sl_method = CategoricalParameter(["Safer", "Balanced", "Risky", "Fixed"], default="Balanced", space="sell")
    tp_method = CategoricalParameter(["Dynamic", "ATR"], default="Dynamic", space="sell")
    adaptive_sl = BooleanParameter(default=True, space="sell")
    ema_length = IntParameter(4, 34, default=9, space="buy")

    # ATR TP/SL multipliers
    atr_period = IntParameter(10, 20, default=12, space="buy")
    atr_tp1_mult = DecimalParameter(0.3, 1.5, default=0.75, space="sell")
    atr_tp2_mult = DecimalParameter(1.0, 2.5, default=1.5, space="sell")
    atr_tp3_mult = DecimalParameter(1.5, 3.5, default=2.25, space="sell")

    # Fixed SL %
    fixed_sl_percent = DecimalParameter(0.5, 3.0, default=1.0, space="sell")

    # Dynamic TP minimal profit %
    min_profit_pct = DecimalParameter(0.1, 1.0, default=0.2, space="sell")
    min_profit_increment_pct = DecimalParameter(0.05, 0.3, default=0.075, space="sell")

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # EMA
        dataframe['ema'] = ta.EMA((dataframe['high'] + dataframe['low']) / 2.0, timeperiod=int(self.ema_length.value))
        # ATR
        dataframe['atr'] = ta.ATR(dataframe, timeperiod=int(self.atr_period.value))

        # ===== Օրվա սկիզբ =====
        dataframe['new_day'] = (dataframe['date'].dt.date != dataframe['date'].dt.date.shift(1)).astype(int)

        # ===== ORB-ի հաշվարկ loop-ով =====
        dataframe['orb_high'] = np.nan
        dataframe['orb_low'] = np.nan
        dataframe['orb_center'] = np.nan
        dataframe['enter_long'] = 0
        dataframe['enter_short'] = 0
        dataframe['exit_long'] = 0
        dataframe['exit_short'] = 0
        dataframe['exit_tag'] = ''

        # ORB-ի և breakout-ի վիճակ
        in_orb = False
        orb_start_idx = None
        orb_high = None
        orb_low = None
        orb_end_idx = None

        breakout_active = False
        breakout_bull = None
        retests = 0
        entry_taken = False
        entry_price = None
        entry_atr = None
        entry_bull = None

        tp1_hit = False
        tp2_hit = False
        tp3_hit = False
        sl_price = None

        retests_needed = {"High": 0, "Medium": 1, "Low": 2, "Lowest": 3}[self.sensitivity.value]

        for idx, row in dataframe.iterrows():
            # 1. Օրվա սկիզբ → վերջացնել նախորդ ORB-ի trade-ը, եթե կա
            if row['new_day']:
                if entry_taken and not (tp1_hit or tp2_hit or tp3_hit or
                                        (sl_price is not None and (
                                            (entry_bull and row['low'] < sl_price) or
                                            (not entry_bull and row['high'] > sl_price)))):
                    # Դուրս գալու ազդանշան
                    if entry_bull:
                        dataframe.at[idx, 'exit_long'] = 1
                        dataframe.at[idx, 'exit_tag'] = 'session_end'
                    else:
                        dataframe.at[idx, 'exit_short'] = 1
                        dataframe.at[idx, 'exit_tag'] = 'session_end'
                # Վերակայել
                in_orb = True
                orb_start_idx = idx
                orb_high = -np.inf
                orb_low = np.inf
                orb_end_idx = None
                breakout_active = False
                breakout_bull = None
                retests = 0
                entry_taken = False
                entry_price = None
                entry_atr = None
                entry_bull = None
                tp1_hit = tp2_hit = tp3_hit = False
                sl_price = None
                continue

            # 2. ORB-ի ընթացքում
            if in_orb:
                bar_time = row['date']
                if (bar_time - dataframe.at[orb_start_idx, 'date']).seconds / 60 < self.orb_minutes.value:
                    orb_high = max(orb_high, row['high']) if orb_high > -np.inf else row['high']
                    orb_low = min(orb_low, row['low']) if orb_low < np.inf else row['low']
                else:
                    in_orb = False
                    orb_end_idx = idx
                    dataframe.at[idx, 'orb_high'] = orb_high
                    dataframe.at[idx, 'orb_low'] = orb_low
                    dataframe.at[idx, 'orb_center'] = (orb_high + orb_low) / 2.0
                    breakout_active = False
                    retests = 0
            else:
                # ORB-ից հետո
                if not entry_taken:
                    if not breakout_active:
                        cond_price = row['close'] if self.breakout_condition.value == 'Close' else row['ema']
                        if cond_price > orb_high:
                            breakout_active = True
                            breakout_bull = True
                        elif cond_price < orb_low:
                            breakout_active = True
                            breakout_bull = False
                    else:
                        if breakout_bull:
                            if row['close'] > orb_high and row['low'] < orb_high:
                                retests += 1
                        else:
                            if row['close'] < orb_low and row['high'] > orb_low:
                                retests += 1
                        if retests >= retests_needed:
                            entry_taken = True
                            entry_bull = breakout_bull
                            entry_price = row['close']
                            entry_atr = row['atr']
                            center = (orb_high + orb_low) / 2.0
                            if self.sl_method.value == 'Fixed':
                                if entry_bull:
                                    sl_price = entry_price * (1 - self.fixed_sl_percent.value / 100)
                                else:
                                    sl_price = entry_price * (1 + self.fixed_sl_percent.value / 100)
                            elif self.sl_method.value == 'Safer':
                                sl_price = (center + orb_high) / 2.0 if entry_bull else (center + orb_low) / 2.0
                            elif self.sl_method.value == 'Balanced':
                                sl_price = center
                            else:  # Risky
                                sl_price = (center + orb_low) / 2.0 if entry_bull else (center + orb_high) / 2.0

                            if entry_bull:
                                dataframe.at[idx, 'enter_long'] = 1
                            else:
                                dataframe.at[idx, 'enter_short'] = 1
                            tp1_hit = tp2_hit = tp3_hit = False
                            continue
                else:
                    # Trade-ը ակտիվ է
                    # --- Take Profit (Dynamic) ---
                    if self.tp_method.value == 'Dynamic':
                        if entry_bull:
                            profitable = row['ema'] > entry_price
                            if profitable:
                                pct = abs(row['ema'] - entry_price) / entry_price * 100
                                if not tp1_hit and pct >= self.min_profit_pct.value and row['close'] < row['ema']:
                                    tp1_hit = True
                                    if self.adaptive_sl.value:
                                        sl_price = entry_price
                                    dataframe.at[idx, 'exit_long'] = 1
                                    dataframe.at[idx, 'exit_tag'] = 'tp1_dynamic'
                                    continue
                                if tp1_hit and not tp2_hit and pct - self.min_profit_pct.value >= self.min_profit_increment_pct.value and row['close'] < row['ema']:
                                    tp2_hit = True
                                    dataframe.at[idx, 'exit_long'] = 1
                                    dataframe.at[idx, 'exit_tag'] = 'tp2_dynamic'
                                    continue
                                if tp2_hit and not tp3_hit and pct - self.min_profit_pct.value - self.min_profit_increment_pct.value >= self.min_profit_increment_pct.value and row['close'] < row['ema']:
                                    tp3_hit = True
                                    sl_price = -1
                                    dataframe.at[idx, 'exit_long'] = 1
                                    dataframe.at[idx, 'exit_tag'] = 'tp3_dynamic'
                                    continue
                        else:  # bearish
                            profitable = row['ema'] < entry_price
                            if profitable:
                                pct = abs(row['ema'] - entry_price) / entry_price * 100
                                if not tp1_hit and pct >= self.min_profit_pct.value and row['close'] > row['ema']:
                                    tp1_hit = True
                                    if self.adaptive_sl.value:
                                        sl_price = entry_price
                                    dataframe.at[idx, 'exit_short'] = 1
                                    dataframe.at[idx, 'exit_tag'] = 'tp1_dynamic'
                                    continue
                                if tp1_hit and not tp2_hit and pct - self.min_profit_pct.value >= self.min_profit_increment_pct.value and row['close'] > row['ema']:
                                    tp2_hit = True
                                    dataframe.at[idx, 'exit_short'] = 1
                                    dataframe.at[idx, 'exit_tag'] = 'tp2_dynamic'
                                    continue
                                if tp2_hit and not tp3_hit and pct - self.min_profit_pct.value - self.min_profit_increment_pct.value >= self.min_profit_increment_pct.value and row['close'] > row['ema']:
                                    tp3_hit = True
                                    sl_price = -1
                                    dataframe.at[idx, 'exit_short'] = 1
                                    dataframe.at[idx, 'exit_tag'] = 'tp3_dynamic'
                                    continue
                    # --- Take Profit (ATR) ---
                    else:
                        atr = row['atr']
                        tp1_price = entry_price + atr * float(self.atr_tp1_mult.value) * (1 if entry_bull else -1)
                        tp2_price = entry_price + atr * float(self.atr_tp2_mult.value) * (1 if entry_bull else -1)
                        tp3_price = entry_price + atr * float(self.atr_tp3_mult.value) * (1 if entry_bull else -1)
                        if not tp1_hit and ((entry_bull and row['high'] >= tp1_price) or (not entry_bull and row['low'] <= tp1_price)):
                            tp1_hit = True
                            if self.adaptive_sl.value:
                                sl_price = entry_price
                            if entry_bull:
                                dataframe.at[idx, 'exit_long'] = 1
                            else:
                                dataframe.at[idx, 'exit_short'] = 1
                            dataframe.at[idx, 'exit_tag'] = 'tp1_atr'
                            continue
                        if tp1_hit and not tp2_hit and ((entry_bull and row['high'] >= tp2_price) or (not entry_bull and row['low'] <= tp2_price)):
                            tp2_hit = True
                            if entry_bull:
                                dataframe.at[idx, 'exit_long'] = 1
                            else:
                                dataframe.at[idx, 'exit_short'] = 1
                            dataframe.at[idx, 'exit_tag'] = 'tp2_atr'
                            continue
                        if tp2_hit and not tp3_hit and ((entry_bull and row['high'] >= tp3_price) or (not entry_bull and row['low'] <= tp3_price)):
                            tp3_hit = True
                            sl_price = -1
                            if entry_bull:
                                dataframe.at[idx, 'exit_long'] = 1
                            else:
                                dataframe.at[idx, 'exit_short'] = 1
                            dataframe.at[idx, 'exit_tag'] = 'tp3_atr'
                            continue

                    # --- Stop Loss ---
                    if sl_price is not None and sl_price != -1:
                        if entry_bull and row['low'] < sl_price:
                            dataframe.at[idx, 'exit_long'] = 1
                            dataframe.at[idx, 'exit_tag'] = 'sl'
                            entry_taken = False
                        elif not entry_bull and row['high'] > sl_price:
                            dataframe.at[idx, 'exit_short'] = 1
                            dataframe.at[idx, 'exit_tag'] = 'sl'
                            entry_taken = False

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # entry ազդանշաններն արդեն լրացված են
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # exit ազդանշաններն արդեն լրացված են
        return dataframe