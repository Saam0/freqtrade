# pragma pylint: disable=missing-docstring, invalid-name, pointless-string-statement
# flake8: noqa: F401
# isort: skip_file
# --- Do not remove these libs ---
import numpy as np
import pandas as pd
from pandas import DataFrame
from datetime import datetime
from typing import Optional, Union

from freqtrade.strategy import (BooleanParameter, CategoricalParameter, DecimalParameter,
                                IStrategy, IntParameter)

# --------------------------------
# Add your lib to import here
import talib.abstract as ta
import freqtrade.vendor.qtpylib.indicators as qtpylib


class BBBreakoutStrategy(IStrategy):
    """
    Bollinger Bands Breakout Strategy
    
    Այս ստրատեգիան օգտագործում է Bollinger Bands ինդիկատորը՝
    - Long ազդանշան, երբ գինը փակվում է վերին գծից վերև
    - Short ազդանշան, երբ գինը փակվում է ստորին գծից ներքև
    
    Default պարամետրեր՝ 55 SMA և 1 ստանդարտ շեղում
    """
    
    # Ստրատեգիայի հիմնական պարամետրեր
    INTERFACE_VERSION = 3
    
    # Կարող եք օգտագործել ցանկացած timeframe
    timeframe = '15m'
    
    # Կանոնիկայի պարամետրեր
    can_short = True
    
    # Stop-loss-ի և take-profit-ի կարգավորումներ
    stoploss = -0.05  # -5% stoploss
    trailing_stop = False
    
    # Առավելագույն մուտքային դիրքեր
    max_entry_position_adjustment = 1
    
    # --------------------------------
    # Օպտիմիզացվող պարամետրեր
    
    # Bollinger Bands-ի պարամետրեր
    bb_length = IntParameter(10, 100, default=55, space="buy")
    bb_std = DecimalParameter(0.5, 3.0, default=1.0, space="buy")
    
    # Առևտրի տեսակ
    trade_type = CategoricalParameter(["long_only", "short_only", "both"], default="both", space="buy")
    
    # --------------------------------
    # Ինդիկատորների հաշվարկման մեթոդ
    
    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        Ավելացնում է բոլոր անհրաժեշտ ինդիկատորները dataframe-ին
        """
        
        # Bollinger Bands
        bollinger = qtpylib.bollinger_bands(
            qtpylib.typical_price(dataframe), 
            window=int(self.bb_length.value), 
            stds=float(self.bb_std.value)
        )
        
        dataframe['bb_lowerband'] = bollinger['lower']
        dataframe['bb_middleband'] = bollinger['mid']
        dataframe['bb_upperband'] = bollinger['upper']
        
        # RSI (կամընտրական - կարող է օգտագործվել որպես լրացուցիչ ֆիլտր)
        # dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)
        
        return dataframe
    
    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        Սահմանում է մուտքի ազդանշանները
        """
        
        # Ստանում ենք trade_type-ի արժեքը
        trade_type_value = self.trade_type.value
        
        # Long ազդանշան - գինը վերևում է upper band-ից
        if trade_type_value in ['long_only', 'both']:
            dataframe.loc[
                (dataframe['close'] > dataframe['bb_upperband']),
                ['enter_long', 'enter_tag']
            ] = (1, 'bb_breakout_long')
        
        # Short ազդանշան - գինը ներքևում է lower band-ից
        if trade_type_value in ['short_only', 'both']:
            dataframe.loc[
                (dataframe['close'] < dataframe['bb_lowerband']),
                ['enter_short', 'enter_tag']
            ] = (1, 'bb_breakout_short')
        
        return dataframe
    
    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        Սահմանում է ելքի ազդանշանները
        """
        
        # Long դիրքից դուրս գալ, երբ short ազդանշան է լինում
        dataframe.loc[
            (dataframe['close'] < dataframe['bb_lowerband']),
            ['exit_long', 'exit_tag']
        ] = (1, 'exit_long_bb_signal')
        
        # Short դիրքից դուրս գալ, երբ long ազդանշան է լինում
        dataframe.loc[
            (dataframe['close'] > dataframe['bb_upperband']),
            ['exit_short', 'exit_tag']
        ] = (1, 'exit_short_bb_signal')
        
        return dataframe