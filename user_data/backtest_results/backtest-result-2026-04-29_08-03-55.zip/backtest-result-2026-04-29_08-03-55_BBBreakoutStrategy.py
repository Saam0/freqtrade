import pandas as pd
import numpy as np
# Ներմուծում ենք պարամետրերի դասերը Freqtrade-ից
from freqtrade.strategy import IStrategy, IntParameter, DecimalParameter

class BBBreakoutStrategy(IStrategy):
    """
    Bollinger Bands Breakout ռազմավարություն՝ Hyperopt պարամետրերով:
    """
    timeframe = '15m'
    
    # Մեր քննարկած ստանդարտ Stop-Loss-ը (գործարքի ավտոմատ փակում 5% մինուսի դեպքում)
    stoploss = -0.05 

    # --- HYPEROPT ՊԱՐԱՄԵՏՐԵՐ ---
    # Փնտրել միջին գծի երկարությունը 20-ից 100 միջակայքում, լռելյայն (default) արժեքը՝ 55
    bb_length = IntParameter(20, 100, default=55, space='buy')
    
    # Փնտրել ստանդարտ շեղումը 1.0-ից 3.0 միջակայքում (մինչև 1 տասնորդական ճշտությամբ)
    bb_std = DecimalParameter(1.0, 3.0, default=1.0, decimals=1, space='buy')

    def populate_indicators(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        """
        1. Ինդիկատորների հաշվարկ: Այստեղ մենք կիրառում ենք Վեկտորացում (Vectorization):
        """
        # .value ատրիբուտով վերցնում ենք պարամետրի այն արժեքը, որը Hyperopt-ը փորձարկում է տվյալ պահին
        length = self.bb_length.value
        std_mult = self.bb_std.value

        # --- ՎԵԿՏՈՐԱՑՎԱԾ ՀԱՇՎԱՐԿ ---
        # .rolling(window).mean() - Սա նշանակում է՝ վերցրու վերջին N մոմերը և գտիր դրանց միջինը: 
        # Բոլոր տողերի համար այն հաշվվում է միանգամից (առանց for loop-ի):
        dataframe['sma'] = dataframe['close'].rolling(window=length).mean()

        # .rolling(window).std() - Հաշվում է ստանդարտ շեղումը (Standard Deviation)
        dataframe['std'] = dataframe['close'].rolling(window=length).std()

        # Հաշվում ենք Վերին (Upper) և Ստորին (Lower) գծերը հենց այնպես, ինչպես Pine Script-ում էր
        dataframe['upper_band'] = dataframe['sma'] + (dataframe['std'] * std_mult)
        dataframe['lower_band'] = dataframe['sma'] - (dataframe['std'] * std_mult)

        return dataframe

    def populate_entry_trend(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        """
        2. Գործարքի մեջ մտնելու (Long) պայմանները
        """
        # loc-ը Pandas-ի ֆունկցիա է, որը գտնում է պայմանին բավարարող բոլոր տողերը
        dataframe.loc[
            (dataframe['close'] > dataframe['upper_band']), # Եթե փակման գինը մեծ է վերին գծից
            'enter_long'
        ] = 1 # Տուր գնման ազդանշան
        
        return dataframe

    def populate_exit_trend(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        """
        3. Գործարքից դուրս գալու (Close) պայմանները
        """
        dataframe.loc[
            (dataframe['close'] < dataframe['lower_band']), # Եթե փակման գինը փոքր է ստորին գծից
            'exit_long'
        ] = 1 # Տուր վաճառքի ազդանշան
        
        return dataframe